const Introduzione = {
  };
  
const Esempi = {
  };
  
const Visualizzazione = {
    data(){
        return{
            rettangoli: null,
            prova: true
        }
    },
    template: `
    <div v-for="(rettangolo, index) in rettangoli">
        <div class = "row" v-if="rettangolo.pos">
            <div class = "col-1 col-md-3"></div>
            <section class = "sinistra mt-3 border-top border-bottom col-10 col-md-10">
                <div class = "row">
                    <div class = "col-md-5 order-md-last">
                        {{index}}
                        <img src="" alt="" class = "col-12 p-0 prova">
                    </div>
                    <div class = "col-md-7">
                        <div class="pt-4">
                            <h2 class="fw-bold">{{rettangolo.Titolo}}</h2>
                        </div>
                        <div id="carouselExample" class="carousel slide pt-2">
                            <div class="carousel-indicators">
                                <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                <button type="button" data-bs-target="#carouselExample" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            </div>
                            <div class="carousel-inner">
                                <div>
                                    <div class = "overflow-hidden">
                                        <div class="carousel-item active">
                                            <p class = "m-0 py-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                        <div class="carousel-item">
                                            <p class = "m-0 pt-2 pb-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo1}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto1}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                        <div class="carousel-item">
                                            <p class = "m-0 pt-2 pb-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo2}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto2}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class = "m-2"></div>
                            <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                                <button class = "btn border-0 p-0" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                                    </svg>
                                </button>
                                <button class = "btn border-0 p-0" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class = "col-1 col-md-2"></div>
        </div>
        <div class = "row" v-if="!rettangolo.pos">
            <div class = "col-1 col-md-2"></div>
            <section class = "destra mt-3 border-top border-bottom col-10 col-md-10">
                <div class = "row">
                    <div class = "col-md-5 p-0">
                        <img src="" alt="" class = "col-12 p-0 prova">
                        {{index}}
                    </div>
                    <div class = "col-md-7">
                        <div>
                            <h2 class="fw-bold">{{rettangolo.Titolo}}</h2>
                        </div>
                        <div id="carouselExample1" class="carousel slide pt-0">
                            <div class="carousel-indicators">
                                <button type="button" data-bs-target="#carouselExample1" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" data-bs-target="#carouselExample1" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                <button type="button" data-bs-target="#carouselExample1" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            </div>                       
                            <div class="carousel-inner">
                                <div>
                                    <div class = "overflow-hidden">
                                        <div class="carousel-item active">
                                            <p class = "m-0 py-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                        <div class="carousel-item">
                                            <p class = "m-0 pt-2 pb-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo1}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto1}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                        <div class="carousel-item">
                                            <p class = "m-0 pt-2 pb-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo2}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto2}}</li>
                                             </ul>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class = "m-2"></div>
                            <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                                <button class = "btn border-0 p-0" type="button" data-bs-target="#carouselExample1" data-bs-slide="prev">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                                    </svg>
                                </button>
                                <button class = "btn border-0 p-0" type="button" data-bs-target="#carouselExample1" data-bs-slide="next">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class = "col-1 col-md-2"></div>
        </div>
    </div>
    `,
                
    methods: {
        getData: function(){
            axios.get("./ogettoprogetto.json")
            .then(response => {
                this.rettangoli = response.data;                
            })
        }
    },
    mounted(){
        this.getData();
    }
};
  
const Operazioni = {
    
  };
  
  
  
  const routes = [
    {
      path: "/", 
      component: Introduzione
    },
    {
      path: "/esempi",
      component: Esempi
    },
    {
      path: "/visualizzazione",
      component: Visualizzazione
    },
    {
      path: "/operazioni",
      component: Operazioni
    }
  ];
  
  const router = VueRouter.createRouter({
    history: VueRouter.createWebHashHistory(),
    routes
  });
  
  const app = Vue.createApp({});
  app.use(router);
  app.mount("#app");