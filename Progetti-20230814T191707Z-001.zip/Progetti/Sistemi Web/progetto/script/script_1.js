const app = Vue.createApp({
    data(){
        return{

        }
    }
});

app.mount("#app");

const app_2 = Vue.createApp({
    data(){
        return{
            i: 0,
            prova2: ["qqqqqqq", "wwwwwww", "eeeeeeeee"],
            prova: [{"1": "aaaaaaa", "2": "bbbbbbbb", "3": "ccccccc"}, {"1": "ddddddddd", "2": "eeeeeeeeee", "3": "fffffffff"}, {"1": "gggggggggg", "2": "hhhhhhhhh", "3": "iiiiiiii"}]
        }
    },
    methods: {
        cambioPage: function(){
            this.i++;
        }
    }
});

app_2.mount("#app_2");