const Introduzione = {
    template: `
    <div class = "row">
    <div class = "col-1 col-xl-3"></div>
    <section class = "sinistra mt-3 border-top border-bottom col-10 col-xl-10">
        <div class = "row">
        <div class = "col-xl-5 order-xl-last">
            <img src="./FOTO/Internationalization-vs-localization.png" alt="" class = "col-12 p-0">
        </div>
        <div class = "col-xl-7">
            <div class="pt-4">
                <h2 class="fw-bold">Internazionalizzazione</h2>
            </div>
            <div id="Carosello" class="carousel slide pt-2">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#Carosello" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#Carosello" data-bs-slide-to="1" aria-label="Slide 2"></button>
                </div>
                <div class="carousel-inner">
                    <div>
                        <div class = "overflow-hidden">
                            <div class="carousel-item active">
                                <p class = "m-0 py-2">Un framework i18n è uno strumento software o una libreria che fornisce supporto per la creazione di applicazioni che possono essere facilmente adattate a lingue, regioni e culture diverse. Aiuta gli sviluppatori a gestire le traduzioni, ad individuare i contenuti specifici del luogo e ad affrontare il processo di creazione di applicazioni in grado di supportare più lingue e contesti culturali. Fornisce strumenti, funzioni e best practice per gestire le traduzioni, i contenuti locali e garantire un'esperienza utente senza soluzione di continuità.</p>
                            </div>
                            <div class="carousel-item">
                                <p class = "m-0 pt-2 pb-2">
                                Alcune caratteristiche principali:
                                <ul>
                                    <li> Gestione delle traduzioni: organizzare, archiviare e recuperare i contenuti tradotti; </li>
                                    <li> Localizzazione: gestire la formattazione specifica locale, come date, numeri e valuta; </li>
                                    <li> Mappatura chiave-valore: associare stringhe o messaggi a chiavi identificative uniche ; </li>
                                    <li> Pluralizzazione e gestione del contesto: supporto delle forme plurali specifiche della lingua e delle traduzioni contestuali; </li>
                                    <li> Integrazione con i framework: integrazione con i framework e le librerie di sviluppo web; </li>
                                </ul>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class = "m-2"></div>
                <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello" data-bs-slide="prev">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                        </svg>
                    </button>
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello" data-bs-slide="next">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class = "col-1 col-xl-2"></div>
  </div>
  <div class = "row">
    <div class = "col-1 col-xl-2"></div>
    <section class = "destra mt-3 border-top border-bottom col-10 col-xl-10">
        <div class = "row">
        <div class = "col-xl-5 p-0">
            <img src="./FOTO/i18nTrend.jpg" alt="" class = "col-12 p-0" longdesc="grafico.txt">
        </div>
        <div class = "col-xl-7">
            <div>
                <h2 class="fw-bold">i18next: Introduzione e Vantaggi</h2>
            </div>
            <div id="Carosello1" class="carousel slide pt-0">
                 <div class="carousel-indicators">
                    <button type="button" data-bs-target="#Carosello1" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#Carosello1" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#Carosello1" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>            
                <div class="carousel-inner">
                    <div>
                        <div class = "overflow-hidden">
                            <div class="carousel-item active pt-2">
                                <p class = "m-0 py-2">i18next è una fra le più popolari libreria di i18n per applicazioni JavaScript e non. Fornisce una soluzione potente e flessibile per tradurre le applicazioni in più lingue, rendendole accessibili a un pubblico globale. Offre in particolare una soluzione completa per la localizzazione dei prodotti, dal web ai dispositivi mobili e desktop.</p>
                            </div>
                            <div class="carousel-item">
                                <p class = "m-0 pt-1 pb-0">
                                I vantaggi:
                                <ul>
                                    <li>Maturità: creato nel 2011, i18next è stato rifinito ed ampliato progressivamente anche dall'impegno della propria community; </li>
                                    <li>Compatibilità: può essere usato con qualsiasi ambiente Javascript e non, indipendentemente da UI framework o formato i18n; </li>
                                    <li>Scalabilità: permette di caricare determinate traduzioni solo su richiesta, velocizzando i caricamenti; </li>
                                    <li>Plugin: gode di un molte funzionalità standard fra le quali, individuazione della lingua, fallback di lingua e namespace, supporto ad oggetti ed array;</li>
                                    <li>Customizzazione: facilita la creazione di soluzioni ad hoc per le proprie istanze.</li>
                                </ul>
                                </p>
                            </div>
                            <div class="carousel-item pt-2">
                                <p class = "m-0 py-2">
                                i18next può essere importato in diversi modi:
                                <ul>
                                    <li>Tramite Node Packet Manager, richiamando le librerie di i18next e le funzionalità all'inizio di ogni progetto; </li>
                                    <li>Attraverso il JS runtime Dino, con apposito link; </li>
                                    <li>Aggiungendolo da CDN allo scritp HTML con apposito tag e link. </li>
                                </ul>
                                Negli esempi presentati in questo contesto, i18next verrà sempre unito ai restanti file tramite NPM.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class = "m-2"></div>
                <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello1" data-bs-slide="prev">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                        </svg>
                    </button>
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello1" data-bs-slide="next">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class = "col-1 col-xl-2"></div>
  </div>
  <div class = "row">
    <div class = "col-1 col-xl-3"></div>
    <section class = "sinistra mt-3 border-top border-bottom col-10 col-xl-10">
        <div class = "row">
        <div class = "col-xl-5 order-xl-last">
            <img src="./FOTO/primoscreen.jpg" alt="funzione di iniziallizzazione della traduzione" class = "col-12 p-0">
        </div>
        <div class = "col-xl-7">
            <div>
                <h2 class="fw-bold">Traduzione con i18next-Vue</h2>
            </div>
            <div id="Carosello2" class="carousel slide">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#Carosello2" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#Carosello2" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#Carosello2" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    <button type="button" data-bs-target="#Carosello2" data-bs-slide-to="3" aria-label="Slide 4"></button>
                </div>  
                <div class="carousel-inner">
                    <div>
                        <div class = "overflow-hidden">
                            <div class="carousel-item active">
                                <p class = "m-0 pt-2 pb-2">Gestione delle traduzioni: i18next consente agli sviluppatori di gestire le traduzioni in modo efficiente. Fornisce una chiara separazione tra il codice e il contenuto della traduzione, consentendo una facile manutenzione e aggiornamento.
                                Le traduzioni possono essere archiviate in file di risorse o database separati, rendendo conveniente l'aggiunta, la modifica o l'estensione del supporto linguistico.
                                Nel nostro approfondimento andremo ad introdurre il plugin specifico di questa libreria per le applicazioni con framework Vue all'interno di un file javascript dedicato.</p>
                            </div>
                            <div class="carousel-item">
                                <p class = "m-0 pt-2 pb-2">Nelle prime tre righe di codice vengono importate in ordine: la libreria i18next, il plugin specifico per l'integrazione con Vue.js e la funzionalità per il rilevamento automatico della lingua.<br>
                                Il secondo passo prevede l'inizializzazione della funzione tramite comando .init e dichiarazione delle opzioni di configurazione:
                                <ul>
                                    <li>debug: abilita la modalità di debug, che genererà in output informazioni diagnostiche alla console;</li>
                                    <li>fallbacklLng: imposta la lingua di default all'italiano se non è disponibile una traduzione nella lingua rilevata o selezionata;</li>
                                </ul>
                                </p>
                            </div>
                            <div class="carousel-item">
                            <p class = "m-0 pt-2 pb-2">
                            <ul>
                               <li>resources: definisce le risorse di traduzione per le diverse lingue, in questo caso inglese e italiano;</li>
                               <li>translation: nome di defualt del namespace, posso dichiarare namespace con diverse traduzioni dello stesso contenuto in file diversi e richiamarli nella mia applicazione tramite notazione dot;</li>
                               <li>intro/contenuto: sono le chiavi del namespace e contengono la traduzione effettiva, possono essere anche innestate;</li>
                            </ul>
                            </p>
                            </div>
                            <div class="carousel-item">
                               <p class = "m-0 pt-2 pb-2">Nelle restanti righe di codice viene definita una funzione di esportazione che riceve come parametro un'applicazione Vue. Questa funzione aggiunge le funzionalità i18next utilizzando il plugin I18NextVue e restituisce l'applicazione modificata. <br>
                               Ciò consente ad altre parti dell'applicazione di utilizzare l'app con i18next integrato.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class = "m-2"></div>
                <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello2" data-bs-slide="prev">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                        </svg>
                    </button>
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello2" data-bs-slide="next">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class = "col-1 col-xl-2"></div>
  </div>
  <div class = "row">
    <div class = "col-1 col-xl-2"></div>
    <section class = "destra mt-3 border-top border-bottom col-10 col-xl-10">
        <div class = "row">
        <div class = "col-xl-5 p-0">
            <img src="./FOTO/secondoscreen.jpg" alt="caricamento delle librerie nella app" class = "col-12 p-0">
        </div>
        <div class = "col-xl-7">
            <div>
                <h2 class="fw-bold">Importazione dei Moduli</h2>
            </div>
            <div id="Carosello3" class="carousel slide">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#Carosello3" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#Carosello3" data-bs-slide-to="1" aria-label="Slide 2"></button>
                </div> 
                <div class="carousel-inner">
                    <div>
                        <div class = "overflow-hidden">
                            <div class="carousel-item active">
                                <p class = "m-0 pt-2 pb-2">All'interno di un secondo file javascript vengono importate:
                                <ul>
                                    <li>La funzione "createApp" dalla libreria Vue.js per consentirci di creare una nuova istanza di applicazione;</li>
                                    <li>L'istanza i18n creata in precedenza;</li>
                                    <li>L'applicazione, contenuta in un terzo file .vue, in formato Single-File Components;</li>
                                </ul>
                                </p>
                            </div>
                            <div class="carousel-item">
                                <p class = "m-0 pt-2 pb-2">Il comando eseguito in ultimo integra i18next-Vue nell'applicazione Vue.js. Richiama la funzione i18n importata, passando l'espressione createApp(App) come argomento.<br>
                                Questo associa i18next-vue all'istanza dell'applicazione Vue.js. Infine, il metodo .mount('#app') monta l'applicazione sull'elemento con id "app" nel documento HTML, renderizzando l'applicazione.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class = "m-2"></div>
                <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello3" data-bs-slide="prev">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                        </svg>
                    </button>
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello3" data-bs-slide="next">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class = "col-1 col-xl-2"></div>
  </div>`
  };
  
const Esempi = {
    template:`
  <div class = "row">
    <div class = "col-1 col-xl-2"></div>
    <section class = "destra mt-3 border-top border-bottom col-10 col-xl-10">
        <div class = "row">
        <div class = "col-xl-5 p-0">
            <img src="./FOTO/quintoscreen.jpg" alt="funzione di inizializzazione della pluralizzazione" class = "col-12 p-0">
        </div>
        <div class = "col-xl-7">
            <div>
                <h2 class="fw-bold">Pluralizzazione</h2>
            </div>
            <div id="Carosello1" class="carousel slide">
                <div class="carousel-inner">
                    <div>
                        <div class = "overflow-hidden">
                            <div class="carousel-item active">
                                <p class = "m-0 pt-2 pb-2">Prendiamo ora in esame il caso della pluralizzazione, una funzionalità che consente alle applicazioni di gestire diverse forme grammaticali basate su valori numerici.<br>
                                Gran parte della struttura introdotta nell'esempio precedente viene ripetuta per impostare questa funzione con solamente una differenza principale:
                                <ul class="mt-2">
                                    <li>aggiungere specifici suffissi alle chiavi create, nell'esempio "zero, one, other";</li>
                                </ul>
                                I suffissi vengono riconosciuti da i18next il quale andrà a sostituire i valori numerici espressi nel "count" della funzione t con quelli associati nelle risorse di traduzione.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class = "m-2"></div>
            </div>
        </div>
        </div>
    </section>
    <div class = "col-1 col-xl-2"></div>
  </div>
  <div class = "row">
    <div class = "col-1 col-xl-3"></div>
    <section class = "sinistra mt-3 border-top border-bottom col-10 col-xl-10">
        <div class = "row">
        <div class = "col-xl-5 order-xl-last">
            <img src="./FOTO/settimoscreen.jpg" alt="caricamento delle librerie nella app" class = "col-12 p-0">
        </div>
        <div class = "col-xl-7">
            <div>
                <h2 class="fw-bold">Formattazione</h2>
            </div>
            <div id="Carosello2" class="carousel slide">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#Carosello2" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#Carosello2" data-bs-slide-to="1" aria-label="Slide 2"></button>
                </div> 
                <div class="carousel-inner">
                    <div>
                        <div class = "overflow-hidden">
                            <div class="carousel-item active">
                                <p class = "m-0 pt-2 pb-2">Fra le API più rilevanti vi è la Formattazione, che permette di convertire automaticamente un certo valore numerico espresso in un dato formato in un altro.<br>
                                Di base vengono offerte funzioni di conversione per contesti che coinvolgono formati numerici, di valuta, di data sia essa relativa (per esprimere un quantitativo temporale in giorni) oppure puntuale (giorno/mese/anno).<br>
                                i18next permette inoltre la creazione di plug-in e API dedicate e customizatte ai propri campi d'impiego.</p>
                            </div>
                            <div class="carousel-item">
                                <p class = "m-0 pt-2 pb-2">Anche per questa istanza la struttura di inizializzazione può rimanere in larga parte invariata, traendo sempre vantaggio dalla funzione di rilevazione automatica della lingua.<br>
                                Le uniche modifiche da apportare risiedono all'interno dei valori delle chiavi di traduzione, che oltre alla funzione "count" presentano anche "number" seguito da un'eventuale impostazione di specifica della parte decimale del numero.<br>
                                Qualora il formato fosse di tipo diverso, dovremmo sostituire number con "currency" o "datetime" oppure "relativetime", ognuna a sua volta seguita da un'opzione.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class = "m-2"></div>
                <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello2" data-bs-slide="prev">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                        </svg>
                    </button>
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello2" data-bs-slide="next">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class = "col-1 col-xl-2"></div>
  </div>
  <div class = "row">
    <div class = "col-1 col-xl-2"></div>
    <section class = "destra mt-3 border-top border-bottom col-10 col-xl-10">
        <div class = "row">
        <div class = "col-xl-5 p-0">
            <img src="./FOTO/terzoscreen.jpg" alt="codice per cambiare lingua" class = "col-12 p-0">
        </div>
        <div class = "col-xl-7">
            <div>
                <h2 class="fw-bold">Definizione Language Switcher</h2>
            </div>
            <div id="Carosello3" class="carousel slide">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#Carosello3" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#Carosello3" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#Carosello3" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div> 
                <div class="carousel-inner">
                    <div>
                        <div class = "overflow-hidden">
                            <div class="carousel-item active">
                                <p class = "m-0 pt-2 pb-2">Il file App.vue è strutturato secondo i seguenti punti:
                                <ul>
                                    <li>Un template al cui interno vengono in primis dichiarate le posizioni del contenuto tramite la funzione t. "t" è una funzione speciale fornita da i18next-vue per la traduzione in cui è possibile specificare una chiave come stringa o più chiavi come array di stringhe, tale funzione restituisce una stringa tradotta individuata dalla chiave 'intro/contenuto'.</li>
                                </ul>
                                </p>
                            </div>
                            <div class="carousel-item">
                                <p class = "m-0 pt-2 pb-2">
                                    <ul>
                                        <li>"div" principale al cui interno viene utilizzata la direttiva "v-if" la quale renderizzerà il contenuto solo se l'oggetto "languages" è definito.</li>
                                        <li>Il primo span che itera le chiavi dell'oggetto "languages" attraverso la direttiva "v-for" assegnando ogni chiave a "lng" e l'indice a "index".</li>
                                        <li>Al suo interno le condizioni espresse all'interno del primo "a" restituiscono un collegamento solo se la lingua corrente ($i18next.resolvedLanguage) non è uguale alla lingua iterata (lng). Tramita la direttiva v-on:clicksi attiva un cambio di lingua tramite  la funzione changeLanguage.</li>
                                    </ul>
                                </p>
                            </div>
                            <div class="carousel-item">
                               <p class = "m-0 pt-2 pb-2">
                                    <ul>
                                        <li>La funzione nel secondo tag "a" rende il nome della lingua in grassetto solo se la lingua corrente è uguale alla lingua iterata.</li>
                                        <li>L'ultima condizione del template inserisce un separatore (|) tra i collegamenti al di fuori dell'ultimo elemento.</li>
                                        <li>Lo script che fa seguito al "template" esporta un oggetto che rappresenta il componente "ProvadiTraduzione". Attraverso la proprietà di data "Languagaes" specifichiamo le lingue disponibili. In questo esempio, contiene due lingue: Italiano (it) e Inglese (en).</li>
                                    </ul>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class = "m-2"></div>
                <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello3" data-bs-slide="prev">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                        </svg>
                    </button>
                    <button class = "btn border-0 p-0" type="button" data-bs-target="#Carosello3" data-bs-slide="next">
                        <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                            <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
        </div>
    </section>
    <div class = "col-1 col-xl-2"></div>
  </div>
    `
  };
  
  const Visualizzazione = {
    data(){
        return{
            rettangoli: null
        }
    },
    template: `
    <div v-for="(rettangolo, index) in rettangoli">
        <div class = "row" v-if="rettangolo.check">
            <div class = "col-1 col-xl-3"></div>
            <section v-bind:class = "rettangolo.pos">
                <div class = "row">
                    <div class = "col-xl-5 order-xl-last">
                        <img v-bind:src="rettangolo.Immagine" alt="" class = "col-12 p-0">
                    </div>
                    <div class = "col-xl-7">
                        <div class="pt-4">
                            <h2 class="fw-bold">{{rettangolo.Titolo}}</h2>
                        </div>
                        <div v-bind:id="rettangolo.id" class="carousel slide pt-2">
                            <div class="carousel-indicators">
                                <button type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                <button type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            </div>
                            <div class="carousel-inner">
                                <div>
                                    <div class = "overflow-hidden">
                                        <div class="carousel-item active">
                                            <p class = "m-0 py-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                        <div class="carousel-item">
                                            <p class = "m-0 pt-2 pb-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo1}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto1}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                        <div class="carousel-item">
                                            <p class = "m-0 pt-2 pb-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo2}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto2}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class = "m-2"></div>
                            <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                                <button class = "btn border-0 p-0" type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide="prev">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                                    </svg>
                                </button>
                                <button class = "btn border-0 p-0" type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide="next">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class = "col-1 col-xl-2"></div>
        </div>
        <div class = "row" v-if="!rettangolo.check">
            <div class = "col-1 col-xl-2"></div>
            <section v-bind:class = "rettangolo.pos">
                <div class = "row">
                    <div class = "col-xl-5 p-0">
                        <img v-bind:src="rettangolo.Immagine" alt="" class = "col-12 p-0">
                    </div>
                    <div class = "col-xl-7">
                        <div>
                            <h2 class="fw-bold">{{rettangolo.Titolo}}</h2>
                        </div>
                        <div v-bind:id="rettangolo.id" class="carousel slide pt-0">
                            <div class="carousel-indicators">
                                <button type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                <button type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            </div>                       
                            <div class="carousel-inner">
                                <div>
                                    <div class = "overflow-hidden">
                                        <div class="carousel-item active">
                                            <p class = "m-0 py-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                        <div class="carousel-item">
                                            <p class = "m-0 pt-2 pb-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo1}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto1}}</li>
                                            </ul>
                                            </p>
                                        </div>
                                        <div class="carousel-item">
                                            <p class = "m-0 pt-2 pb-2">
                                            <h3 class="fs-5">{{rettangolo.Sottotitolo2}}</h3>
                                            <ul>
                                                <li>{{rettangolo.Contenuto2}}</li>
                                             </ul>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class = "m-2"></div>
                            <div class="gap-2 d-flex justify-content-end col-12 pb-2">
                                <button class = "btn border-0 p-0" type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide="prev">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-left-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 0 0 16A8 8 0 0 0 8 0zm3.5 7.5a.5.5 0 0 1 0 1H5.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L5.707 7.5H11.5z"/>
                                    </svg>
                                </button>
                                <button class = "btn border-0 p-0" type="button" v-bind:data-bs-target="rettangolo.classe" data-bs-slide="next">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="white" class="bi bi-arrow-right-circle-fill" viewBox="0 0 16 16">
                                        <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0zM4.5 7.5a.5.5 0 0 0 0 1h5.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H4.5z"/>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class = "col-1 col-xl-2"></div>
        </div>
    </div>
    `,
                
    methods: {
        getData: function(){
            axios.get("./ogettoprogetto.json")
            .then(response => {
                this.rettangoli = response.data;                
            })
        }
    },
    mounted(){
        this.getData();
    }
};
  
const Operazioni = {
    data(){
        return{
            check: false,
            ind: 0,
            oggetto: null,
            aggiungi: {Titolo: '', Richiesta: ''},
            crea: false,
            modifica: false,
            elimina: false
        }
    },
    methods: {
        getData: function(){
            axios.get("./richieste.json")
            .then(response => {
                this.oggetto = response.data;                
            })
        },
        creAte: function(){
            this.oggetto.push(this.aggiungi);
            this.aggiungi = {Titolo: '', Richiesta: ''};
            this.i = true;
        },
        delEte: function(){
            if(this.ind > 0)
            {
               if(this.ind === this.oggetto.length - 1)
                {
                    this.ind--;
                    this.oggetto.pop();   
                }
                else
                {
                    this.oggetto.splice(this.ind, 1);
                }    
            }
        },
        clickCrea: function(){
            if(this.crea === false)
            {
                this.crea = true;
                this.modifica = false;
                this.elimina = false;
            }
            else
            {
                this.crea = false;
            }
        },
        clickModifica: function(){
            if(this.modifica === false)
            {
                this.ind = 0;
                this.modifica = true;
                this.crea = false;
                this.elimina = false;
            }
            else
            {
                this.modifica = false;
            }
        },
        clickElimina: function(){
            if(this.elimina === false)
            {
                this.ind = 0;
                this.elimina = true;
                this.modifica = false;
                this.crea = false;
            }
            else
            {
                this.elimina = false;
            }
        },
        funBlocca: function(){
            if(this.ind === 0)
            {
                this.check = true;
            }
            else
            {
                this.check = false;
            }
        },
        bloccaDel: function(){
            this.check = false;
        }                
    },
    template: `
    <div class = "container-fluid overflow-hidden p-0">
        <div class = "row">

            <div class = "col-1 col-md-1"></div>
            <div class = "col-10 col-md-10 p-0">
                <div class="row col-md-12 text-center p-4">
                    <div class="col-md-4"></div>
                    <div class="btn-group col-md-4" role="group" aria-label="Basic radio toggle button group">
                        <input type="radio" @click = "clickCrea" value = "Crea" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off" checked>
                        <label class="btn btn-outline-primary fw-bold" for="btnradio1">Crea</label>
    
                        <input type="radio" @click = "clickModifica" value = "Modifica" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off">
                        <label class="btn btn-outline-primary fw-bold" for="btnradio2">Modifica</label>

                        <input type="radio" @click = "clickElimina" value = "Elimina" class="btn-check" name="btnradio" id="btnradio3" autocomplete="off">
                        <label class="btn btn-outline-primary fw-bold" for="btnradio3">Elimina</label>
                    </div>
                    <div class="col-md-4"></div>
                </div>

                <div class="row col-md-12 text-center">
                    <div v-if = "crea" class="justify-content-center">
                        <input @click = "creAte" type="button" value = "Crea" class="btn btn-secondary mb-2"/>
                        <div class="mb-3">
                            <label for="Form" class="form-label">Title</label>
                            <input  v-model = "aggiungi.Titolo" type="text" class="form-control" id="Form" placeholder="Add Title Here">
                        </div>
                        <div class="mb-3">
                            <label for="Form Richiesta" class="form-label">Your Request</label>
                            <textarea v-model = "aggiungi.Richiesta" class="form-control" id="Form" rows="3" placeholder="Add Request Here"></textarea>
                        </div>
                    </div>


                    <div v-if = "modifica">
                        <select id="modifica" v-model = "ind" @click = "bloccaDel" class="mb-2">
                            <option v-for = "(n, index) in oggetto" v-bind:value = "index">
                                {{n.Titolo}}
                            </option>
                        </select>            
                        <div class="mb-3">
                            <label for="Form" class="form-label">Title</label>
                            <input  v-model = "oggetto[ind].Titolo" type="text" class="form-control" @click = "funBlocca" :disabled = "check" id="Form">
                        </div>
                        <div class="mb-3">
                            <label for="Form Richiesta" class="form-label">Request</label>
                            <textarea v-model = "oggetto[ind].Richiesta" class="form-control" id="Form" @click = "funBlocca" :disabled = "check" rows="3"></textarea>
                        </div>
                    </div>


                    <div v-if = "elimina">
                        <input @click = "delEte" type="button" value = "Cancella" class="btn btn-secondary me-2"/>
                        <select id="modifica" v-model = "ind">
                            <option v-for = "(n, index) in oggetto" v-bind:value = "index">
                                {{n.Titolo}}
                            </option>
                        </select>
                    </div>
                </div>
            </div>
            <div class = "col-1 col-md-1"></div>
        
        </div>

        <div class="row text-black">
            <div class="col-12 col-md-12">
                <div class="row row-cols-1 row-cols-md-2 g-4 justify-content-center m-4">
                    <template v-for = "(n, index) in oggetto">
                    <div class="col-10 col-md-3" v-if= "index > 0" >
                        <div class="card bg-warning"  >
                            <div class="card-body">
                                <h3 class="card-title border-bottom border-1 border-dark">{{n.Titolo}}</h3>
                                <p class="card-text">{{n.Richiesta}}</p>
                            </div>
                        </div>
                    </div>
                    </template>
                </div>
            </div>
        </div>
    </div>`,
    mounted(){
        this.getData();
    }
  };
  
  
  
  const routes = [
    {
      path: "/", 
      component: Introduzione
    },
    {
      path: "/esempi",
      component: Esempi
    },
    {
      path: "/visualizzazione",
      component: Visualizzazione
    },
    {
      path: "/operazioni",
      component: Operazioni
    }
  ];
  
  const router = VueRouter.createRouter({
    history: VueRouter.createWebHashHistory(),
    routes
  });
  
  const app = Vue.createApp({});
  app.use(router);
  app.mount("#app");