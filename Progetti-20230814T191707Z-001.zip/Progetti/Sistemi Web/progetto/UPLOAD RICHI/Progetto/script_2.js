document.getElementById('scrollButton1').addEventListener('click', function (event) {
  event.preventDefault();
  var targetElement = document.getElementById('section2');
  targetElement.scrollIntoView({ behavior: 'smooth' });
});
document.getElementById('scrollButton2').addEventListener('click', function (event) {
  event.preventDefault();
  var targetElement = document.getElementById('section1');
  targetElement.scrollIntoView({ behavior: 'smooth' });
});